<!-- Footer -->
  <section>
    <div class="footer-container">
      <footer class="short bg-secondary-1">
        <div class="container">
          <div class="row">
            <div class="col-md-3 col-sm-10">
              <p class="q">Copyright © 2019 O.F.A</p>
            </div>
            <div class="col-lg-2 col-sm-10"><a href="#" style=" color:white; text-decoration: none;">
                <p class="q">Terms Of Use</p>
              </a> </div>
            <div class="col-lg-3 col-sm-10"><a href="#" style=" color:white; text-decoration: none;">
                <p class="q">Privacy&SecurityStatement</p>
              </a> </div>
            <div class="col-lg-2 col-sm-10"><a href="#" style=" color:white; text-decoration: none;">
                <p class="q">Sitemap</p>
              </a> </div>
            <div class="col-xl-2 col-sm-2 text-right"><a href="https://twitter.com/"><i class="fab fa-twitter"></i></a>
              &nbsp;
              <a href="https://www.facebook.com/"><i class="fab fa-facebook-f"></i></a></div>
          </div>
        </div>
      </footer>
    </div>
  </section>

  

  <script src="js/all.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js1.js"></script>
  <script type="text/javascript" src="js/js1.js"></script>

  <script type="text/javascript">
  /*  
   $(".img").mouseenter(function(){
       $(this).siblings().show();
    });
  
     $(".img").mouseleave(function(){
       $('#none1').hide();
    });

     

     $("#none1").mouseenter(function(){
       $("#none1").show();
    });

     $("#none1").mouseleave(function(){
       $('#none1').hide();
    });
*/
  
/*
  $("#mov").mouseenter(function(){
       $("#none1").css('display', 'block');
    });

     $("#mov").mouseleave(function(){
       $("#none1").css('display', 'none');
    });

    
  </script>

  <script type="text/javascript">
    
  </script>
</body>
</html>

