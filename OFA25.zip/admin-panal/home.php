<?php
	include 'panalheader.php';
?>
<div class="container">
	<div class="row">
		
<div class="col-sm-6 col-xs-12 body_container">
	<form>
<div class="panal_body">
	
</div>
</form>
</div>
</div>
</div>