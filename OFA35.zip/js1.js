

function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
  }
  function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
  }

function changepass(){
	getElementById('newpass').style.display='block';
	getElementById('lastpass').style.display='none';

}

  $(document).ready(function(){
$(".dropdown").hover(function(){
       $(this).children(".dropdown-menu").toggleClass("show");
    });

	
/*
	$(".img").mouseenter(function(){
       $(this).siblings().show();
    });
	
     $(".img").mouseleave(function(){
       $('#none1').hide();
    });

     

     $("#none1").mouseenter(function(){
       $("#none1").show();
    });

     $("#none1").mouseleave(function(){
       $('#none1').hide();
    });

   */  


// If user clicks anywhere outside of the modal, Modal will close

var modal = document.getElementById('modal-wrapper');
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}


$("#server1").click(function(){
		$("#open").hide();
		$("#local").css("display","block");
		
	});

$("#server2").click(function(){
		$("#local").hide();
		$("#open").css("display","block");
		
	});


  // If user clicks anywhere outside of the modal, Modal will close

  var modal2 = document.getElementById('m');
  window.onclick = function (event) {
    if (event.target == modal2) {
      modal2.style.display = "none";
      $('#opentr').attr('src', 'none');
    }
  }








});