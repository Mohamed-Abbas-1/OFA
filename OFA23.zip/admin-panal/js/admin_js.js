function openNav() {
    document.getElementById("mySidenav").style.width = "17vw";
  }
  function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
  }