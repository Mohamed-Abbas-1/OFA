<?php
  include 'panalheader.php';
?>

<?php
  
  
    if (isset($_GET['action'])) {
      $id = $_GET['action'];
    }
?>

<script>
          /*
           Search engine script
          */
function fill(Value) {
   //Assigning value to "search" div in "search.php" file.
   $('#search').val(Value);
   //Hiding "display" di v in "search.php" file.
   $('#display').hide();
} 
$(document).ready(function() {
   //On pressing a key on "Search box" in "search.php" file. This function will be called.
   $("#search").keyup(function() {
       //Assigning search box value to javascript variable named as "name".
       var name = $('#search').val();
       //Validating, if "name" is empty.
       if (name == "") {
           //Assigning empty value to "display" div in "search.php" file.
           $("#display").html("");
       }
       //If name is not empty.
       else {
           //AJAX is called.
           $.ajax({
               //AJAX type is "Post".
               type: "POST",
               //Data will be sent to "ajax.php".
               url: "search/deletemov.php",
               //Data, that will be sent to "ajax.php".
               data: {
                   //Assigning value of "name" into "search" variable.
                   search: name
               },
               //If result found, this funtion will be called.
               success: function(html) {
                   //Assigning result to "display" div in "search.php" file.
                   $("#display").html(html).show();
               }
           });
       }
   });
});

</script>

<div class="container">
	<div class="row">
		
<div class="col-sm-6 col-xs-12 body_container">
	
<div class="panal_body" style="min-height: 80vh;">
	<div class="addmoviebody">
		
	<div class="col-md-12" style="margin-top: 4vh;">
		<div style="float: right;">
			 <div class="row" style="display: inline-block;">
          <input class="form-control mr-sm-4 glyphicon search" type="search" placeholder="Search Movies" 
            style="border-radius: 50cm; background-color: rgba(0,0,0,0.3);border: 1px solid grey;color: white;
                      margin-left: 15px;width: 20vw;"
                      id="search" name="search" >
          <div id="display" name="name" class="search-engine comments3"  style="font-size: 22px"></div>

  </div>
		</div>
	</div>
	<div style="margin-top: 3vh;font-size: 30px;">Delete Movie</div>
	<?php
	if (isset($_GET['action'])) {
		$Query = "SELECT * FROM movie WHERE id = '$id' ORDER BY created_at DESC";
//Query execution

   $ExecQuery = MySQLi_query($con, $Query);
//Creating unordered list to display result.
  if (mysqli_num_rows($ExecQuery) > 0) {
   //Fetching result from database.
   while ($Result = MySQLi_fetch_array($ExecQuery)) {
       ?>
       <div class="container" style="margin-top: 4vh;">
       <div class="row">
       <div class="col-md-3">
       	<img style="" class="poster3" src="../images/poster/<?php echo $Result['poster']; ?>">
       </div>
       <div class="col-md-9" style="background: rgba(0,0,0,0.2);text-align: left;">
       	<div>
       		Name: 
       		<?php echo $Result['name2']; ?>
       		(<?php echo $Result['release_date']; ?>)
       	</div>
       	<div>
       		Description: 
       		<?php echo $Result['desciption'] ?>
       	</div>
       	<div>
       		qulity: 
       		<?php echo $Result['qulity'] ?>
       	</div>
       	<div>
       		Country: 
       		<?php echo $Result['country'] ?>
       	</div>
       	<div>
       		Added At: 
       		<?php echo $Result['created_at'] ?>
       	</div>
       	<div style="float: right;">
       		<button id="deletemovie" class="btn btn-danger">Delete</button>
       	</div>
       </div>
   </div></div>

		</div>
	</div>


<?php } }else{
	echo "No Movie With this Name";
}  }else{?>
	<br><br><br><br>
	<span style="font-size: 35px;">
		<?php
	echo "No Movie Selected Yet!" ;?>
		
	</span>
	<?php
}?>
</div>
</div>

</div>
</div>
</div>